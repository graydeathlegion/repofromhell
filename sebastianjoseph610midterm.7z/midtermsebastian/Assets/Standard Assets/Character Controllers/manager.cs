﻿using UnityEngine;
using System.Collections;

public class manager : MonoBehaviour {
	GameObject player;
	GameObject Cube1;
	GameObject Cube2;
	GameObject Sphree1;
	GameObject Sphree2;
	GameObject  Sphree3;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {


	}
	void Oncollsion(Collider Player)

	{
		if (Player == GameObject.FindWithTag("Cube1"  ))
		    {
			Sphree1.renderer.material.color(red);
			Sphree2.renderer.material.color(red);
			Sphree3.renderer.material.color(red);

		}
		if (Player == GameObject.FindWithTag("Cube2"  ))
		{
			Sphree1.renderer.material.color(yellow);
			Sphree2.renderer.material.color(yellow);
			Sphree3.renderer.material.color(yellow);
				
		}

		
		
	}

}
